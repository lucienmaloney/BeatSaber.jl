include("BeatSaber.jl")
using .BeatSaber

mapsongs(ARGS)
