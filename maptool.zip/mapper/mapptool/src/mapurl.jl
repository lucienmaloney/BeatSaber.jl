include("BeatSaber.jl")
using .BeatSaber

mapurl(ARGS[1])
